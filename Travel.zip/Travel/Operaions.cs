﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Text;

namespace Travel
{
    public class Operaions
    {
        public List<DBItem> Get(int lIndex)
        {
            SqlConnection conn = new SqlConnection("workstation id=TariaAgency.mssql.somee.com;packet size=4096;user id=TariaNew_SQLLogin_1;pwd=cxx6jhtvpr;data source=TariaAgency.mssql.somee.com;persist security info=False;initial catalog=TariaAgency");
            string sql = "SELECT id, name, city, message FROM comments WHERE id > " + lIndex;
            List<DBItem> list = new List<DBItem>();

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);

                using (DbDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.HasRows)
                    {

                        while (reader.Read())
                        {
                            DBItem item = new DBItem();
                            item.Id = reader[0].ToString();
                            item.Name = reader[1].ToString();
                            item.City = reader[2].ToString();
                            item.Message = reader[3].ToString();
                            list.Add(item);
                        }
                    }
                }
            }
            catch (Exception)
            { }
            finally
            {
                conn.Close();
                //conn.Dispose();
            }

            return list;
        }

        public void Post(DBItem dbItem)
        {
            SqlConnection conn = new SqlConnection("workstation id=TariaAgency.mssql.somee.com;packet size=4096;user id=TariaNew_SQLLogin_1;pwd=cxx6jhtvpr;data source=TariaAgency.mssql.somee.com;persist security info=False;initial catalog=TariaAgency");
            string sql = "INSERT INTO comments (name, city, message) VALUES (N'" + dbItem.Name + "', N'" + dbItem.City + "', N'" + dbItem.Message + "')";

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);

                int res = cmd.ExecuteNonQuery();
            }
            catch (Exception)
            { }
            finally
            {
                conn.Close();
                //conn.Dispose();
            }
        }
    }
}
