﻿using System;

namespace Travel
{
    class Program
    {
        static void Main(string[] args)
        {
            Operaions a = new Operaions();
            //a.Post(new DBItem { Name = "Kolia", City = "Jitomir", Message = "Hello from Jitomir" });
            Console.WriteLine(a.Get(1).Count);
        }
    }
}
